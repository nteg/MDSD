//0
package main.service.intrfaceImpl;

import main.domainObjects.*;
import main.service.intrface.*;
import java.util.logging.Logger;
import main.dao.intrface.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class EmpServiceImpl implements EmpService {
	
@Autowired 
EmpDao empdao;
	
Logger logger = Logger.getLogger(EmpServiceImpl.class.getName());
	

//Employee emp
//Employee emp,
//Employee emp,int age
//Employee emp,int age,

// 20

/**
* @ReturnType: Void
* @Author: Nagarro Inc
*/ 
public Void saveEmp(Employee emp,int age )
{
	logger.info("*** inside saveEmp");
Void obj=null;
// Update with business logic
return obj;
 }



//int empId
//int empId,

// 9

/**
* @ReturnType: Employee
* @Author: Nagarro Inc
*/ 
@Cacheable(value="empDetails")
public Employee getEmpDetails(int empId )
{
	logger.info("*** inside service layer getEmpDetails");
Employee obj=null;
obj=empdao.getEmpDetails(empId);
return obj;
 }


}	
