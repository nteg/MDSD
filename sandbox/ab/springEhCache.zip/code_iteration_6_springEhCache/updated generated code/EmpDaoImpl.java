//0
package main.dao.intrfaceImpl;
import java.util.logging.Logger;
import main.domainObjects.*;
import main.dao.intrface.*;
import org.springframework.stereotype.Repository;

@Repository
public class EmpDaoImpl implements EmpDao{
	
Logger logger = Logger.getLogger(EmpDaoImpl.class.getName());

//Employee emp
//Employee emp,
//Employee emp,int age
//Employee emp,int age,

// 20

/**
* @ReturnType: Void
* @Author: Nagarro Inc
*/ 
public Void saveEmp(Employee emp,int age )
{
	logger.info("*** inside saveEmp");
Void obj=null;
// Update with business logic
return obj;
 }



//int empId
//int empId,

// 9

/**
* @ReturnType: Employee
* @Author: Nagarro Inc
*/ 
public Employee getEmpDetails(int empId )
{
	logger.info("*** inside DAO layer getEmpDetails for empID: "+empId);
	Employee obj=new Employee();
	if(empId==5){
obj.setEmpName("Bond");
obj.setSal(100);
	}
	else
	{
obj.setEmpName("dummy");
obj.setSal(10);
    }
// Update with business logic
return obj;
 }


}
